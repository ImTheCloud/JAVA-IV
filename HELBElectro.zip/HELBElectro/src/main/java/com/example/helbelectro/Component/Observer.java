package com.electro.helbelectro.Component;

public interface Observer {

    void update(Object o);
}


