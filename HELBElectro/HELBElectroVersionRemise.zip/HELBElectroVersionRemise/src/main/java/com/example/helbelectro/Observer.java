package com.example.helbelectro;

public interface Observer {
    void onOptiChoiceSelected(String selectedItem);
}

