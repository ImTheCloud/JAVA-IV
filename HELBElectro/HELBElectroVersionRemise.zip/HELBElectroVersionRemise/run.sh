mvn clean javafx:run
