mvn clean 
mvn test
