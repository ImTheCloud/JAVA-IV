mvn clean
mvn test