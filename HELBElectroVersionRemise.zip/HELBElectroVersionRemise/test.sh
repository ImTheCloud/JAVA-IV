mvn clean 
mvn test javafx:run
