package com.example.helbelectro.product.strategyProduct;

import com.example.helbelectro.product.*;

public interface ProductCreationStrategy {
    Product createProduct();
}

