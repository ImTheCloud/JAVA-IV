package com.example.helbelectro.conponent;

public interface Component {
    String getName();
    String getColor();

}
